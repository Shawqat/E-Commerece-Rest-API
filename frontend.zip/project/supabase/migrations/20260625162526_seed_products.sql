INSERT INTO products (name, price, description, image, category, stock) VALUES
('Wireless Headphones', 79.99, 'Premium noise-canceling wireless headphones with 30-hour battery life.', 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400', 'electronics', 25),
('Smart Watch', 149.99, 'Fitness tracking smartwatch with heart rate monitor and GPS.', 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=400', 'electronics', 30),
('Running Shoes', 89.99, 'Lightweight breathable running shoes with cushioned sole.', 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400', 'fashion', 40),
('Backpack', 49.99, 'Durable water-resistant backpack with laptop compartment.', 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=400', 'fashion', 20),
('Coffee Maker', 119.99, 'Programmable drip coffee maker with thermal carafe.', 'https://images.pexels.com/photos/4109748/pexels-photo-4109748.jpeg?auto=compress&cs=tinysrgb&w=400', 'home', 15),
('Yoga Mat', 29.99, 'Non-slip eco-friendly yoga mat with carrying strap.', 'https://images.pexels.com/photos/4498312/pexels-photo-4498312.jpeg?auto=compress&cs=tinysrgb&w=400', 'fitness', 50),
('Bluetooth Speaker', 59.99, 'Portable waterproof Bluetooth speaker with 12-hour playtime.', 'https://images.pexels.com/photos/1279365/pexels-photo-1279365.jpeg?auto=compress&cs=tinysrgb&w=400', 'electronics', 35),
('Sunglasses', 39.99, 'UV400 polarized sunglasses with lightweight frame.', 'https://images.pexels.com/photos/1362558/pexels-photo-1362558.jpeg?auto=compress&cs=tinysrgb&w=400', 'fashion', 60);
