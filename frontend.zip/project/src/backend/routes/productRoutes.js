const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const authController = require('../controllers/authController');

router.route('/')
        .post(authController.protect, authController.restrictTo('admin'), productController.createProduct)
        .get(productController.getAllProducts);

router.route('/:slug')
        .get(productController.getProductBySlug)
        .patch(authController.protect, authController.restrictTo('admin'), productController.updateProduct)
        .delete(authController.protect, authController.restrictTo('admin'), productController.deleteProduct);

module.exports = router;
