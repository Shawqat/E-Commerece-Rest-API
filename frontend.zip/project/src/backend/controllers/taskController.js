const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../tasks.json');

const readDataFromFile = () => {
    const fileData = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(fileData); 
};

const writeDataToFile = (data) => {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
};

// read all tasks
exports.getAllTasks = (req, res) => {
    const tasks = readDataFromFile();
    res.json(tasks);
};

// read a specific task by id
exports.getTaskById = (req, res) => {
    const taskId = parseInt(req.params.id);
    const tasks = readDataFromFile();
    const task = tasks.find(task => task.id === taskId);
    if (!task) {
        return res.status(404).json({ message: "task not found" });
    }
    res.json(task);
};

// create a new task
exports.createTask = (req, res) => {
   const tasks = readDataFromFile();
    
    const newTask = {
        id: tasks.length > 0 ? tasks[tasks.length - 1].id + 1 : 1, 
        title: req.body.title,
        completed: false
    };

    tasks.push(newTask);
    writeDataToFile(tasks);

    res.status(201).json({ message: "task added successfully", task: newTask });
};

// edit a task by id
exports.updateTask = (req, res) => {
    const taskId = parseInt(req.params.id);
    const tasks = readDataFromFile();
    const task = tasks.find(task => task.id === taskId);

    if (!task) {
        return res.status(404).json({ message: "task not found" });
    }

    task.title = req.body.title || task.title;
    task.completed = req.body.completed !== undefined ? req.body.completed : task.completed;
    writeDataToFile(tasks);
    res.json({
        message: "task updated successfully",
        task: task
    });
};

// delete a task by id
exports.deleteTask = (req, res) => {
    const taskId = parseInt(req.params.id);
    const tasks = readDataFromFile();
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex === -1) {
        return res.status(404).json({ message: "task not found" });
    }

    tasks.splice(taskIndex, 1);
    writeDataToFile(tasks);
    res.json({ message: "task deleted successfully" });
};
