require('dotenv').config({ path: './src/backend/.env' });
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/shopify';

mongoose.connect(MONGODB_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// ========== API ROUTES ==========
const productRoutes = require('./routes/productRoutes');
const authController = require('./controllers/authController');

app.use('/api/v1/products', productRoutes);
app.post('/api/v1/auth/signup', authController.signup);
app.post('/api/v1/auth/login', authController.login);
app.get('/api/v1/auth/me', authController.protect, async (req, res) => {
  res.status(200).json({ status: 'success', data: { user: req.user } });
});

// ========== STATIC FRONTEND ==========
app.use(express.static(path.join(__dirname, '../../public')));

// SPA fallback: send index.html for all non-API routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
