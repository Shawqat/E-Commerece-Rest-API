/* ================= E-COMMERCE SPA ================= */
const API = 'http://localhost:3000/api/v1';

let state = {
  token: localStorage.getItem('token') || null,
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  products: [],
  view: 'home',
  slug: null,
  loading: false,
  search: '',
  category: 'all',
};

/* ================= API CLIENT ================= */
const api = {
  async fetch(url, opts = {}) {
    const headers = { 'Content-Type': 'application/json', ...opts.headers };
    if (state.token) headers['Authorization'] = `Bearer ${state.token}`;
    const res = await fetch(`${API}${url}`, { ...opts, headers });
    if (res.status === 401) {
      logout();
      showToast('Session expired, please login again.', 'error');
      return null;
    }
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: 'Request failed' }));
      throw new Error(err.message || err.error?.message || 'Request failed');
    }
    return res.status === 204 ? null : res.json();
  },

  login: (email, password) => api.fetch('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  signup: (name, email, password, passwordConfirm) => api.fetch('/auth/signup', { method: 'POST', body: JSON.stringify({ name, email, password, passwordConfirm }) }),
  me: () => api.fetch('/auth/me'),
  products: (params = '') => api.fetch(`/products${params}`),
  product: (slug) => api.fetch(`/products/${slug}`),
  createProduct: (data) => api.fetch('/products', { method: 'POST', body: JSON.stringify(data) }),
  updateProduct: (slug, data) => api.fetch(`/products/${slug}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteProduct: (slug) => api.fetch(`/products/${slug}`, { method: 'DELETE' }),
};

/* ================= HELPERS ================= */
function showToast(msg, type = 'info') {
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<div class="flex items-center gap-2"><span class="${type === 'error' ? 'text-red-400' : 'text-emerald-400'}">●</span> ${msg}</div>`;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

function formatPrice(p) { return `$${Number(p).toFixed(2)}`; }
function $(s) { return document.querySelector(s); }
function $$(s) { return document.querySelectorAll(s); }

function loginUser(token, user) {
  state.token = token;
  state.user = user;
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
}

function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  state.view = 'home';
  render();
}

function navigate(view, data = {}) {
  state.view = view;
  if (data.slug) state.slug = data.slug;
  render();
}

function getHashParams() {
  const h = window.location.hash.slice(1);
  if (h === 'login') return { view: 'login' };
  if (h === 'register') return { view: 'register' };
  if (h === 'products') return { view: 'products' };
  if (h === 'admin') return { view: 'admin' };
  if (h.startsWith('product/')) return { view: 'product', slug: h.split('/')[1] };
  return { view: 'home' };
}

/* ================= RENDER ================= */
function render() {
  const app = $('#app');
  if (!app) return;
  app.innerHTML = `${renderNavbar()}<main class="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200">${renderContent()}</main>${renderFooter()}`;
  attachEvents();
}

function renderNavbar() {
  const isAdmin = state.user?.role === 'admin';
  return `
  <nav class="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16">
        <a href="#" class="flex items-center gap-2 text-xl font-bold text-emerald-700" data-nav="home">
          <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          Shopify
        </a>
        <div class="hidden md:flex items-center gap-1">
          <a href="#" class="btn-ghost" data-nav="home">Home</a>
          <a href="#products" class="btn-ghost" data-nav="products">Products</a>
          ${isAdmin ? '<a href="#admin" class="btn-ghost" data-nav="admin">Admin</a>' : ''}
        </div>
        <div class="flex items-center gap-3">
          ${state.user
            ? `<div class="flex items-center gap-3">
                <span class="hidden sm:inline text-sm text-slate-600 font-medium">${state.user.name}</span>
                <button id="logoutBtn" class="btn-secondary text-sm">Logout</button>
              </div>`
            : `<a href="#login" class="btn-primary text-sm" data-nav="login">Login</a>`
          }
        </div>
      </div>
    </div>
  </nav>`;
}

function renderFooter() {
  return `
  <footer class="bg-white border-t border-slate-100 mt-12">
    <div class="max-w-7xl mx-auto px-4 py-8 text-center text-sm text-slate-400">
      <p>Shopify E-Commerce. Built with Express, MongoDB, and Tailwind.</p>
    </div>
  </footer>`;
}

function renderContent() {
  if (state.loading) {
    return `
    <div class="flex items-center justify-center min-h-[60vh]">
      <div class="text-center text-slate-400">
        <svg class="w-10 h-10 animate-spin mx-auto mb-3" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
        <p>Loading...</p>
      </div>
    </div>`;
  }

  switch (state.view) {
    case 'home': return renderHome();
    case 'products': return renderProducts();
    case 'product': return renderProductDetail();
    case 'login': return renderLogin();
    case 'register': return renderRegister();
    case 'admin': return renderAdmin();
    default: return renderHome();
  }
}

/* ================= HOME ================= */
function renderHome() {
  const featured = state.products.slice(0, 4);
  const cats = ['electronics', 'fashion', 'home', 'fitness'];
  return `
  <div class="animate-fade-in">
    <div class="relative bg-emerald-700 overflow-hidden">
      <div class="absolute inset-0 bg-[url('https://images.pexels.com/photos/5632397/pexels-photo-5632397.jpeg?auto=compress&cs=tinysrgb&w=1200')] bg-cover bg-center opacity-10"></div>
      <div class="relative max-w-7xl mx-auto px-4 py-20 sm:py-28 text-center">
        <h1 class="text-4xl sm:text-5xl font-bold text-white mb-4 tracking-tight">Discover Amazing Products</h1>
        <p class="text-emerald-100 text-lg mb-8 max-w-2xl mx-auto">Shop the latest trends with fast delivery.</p>
        <div class="flex gap-4 justify-center">
          <a href="#products" class="bg-white text-emerald-700 px-6 py-3 rounded-xl font-semibold hover:bg-emerald-50 transition-colors" data-nav="products">Shop Now</a>
          <a href="#login" class="border border-white/30 text-white px-6 py-3 rounded-xl font-semibold hover:bg-white/10 transition-colors" data-nav="login">${state.user ? 'My Account' : 'Get Started'}</a>
        </div>
      </div>
    </div>
    <div class="max-w-7xl mx-auto px-4 py-12">
      <h2 class="text-2xl font-bold text-slate-800 mb-6">Categories</h2>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        ${cats.map(cat => `
          <button class="card p-6 text-center cursor-pointer group" data-cat="${cat}">
            <div class="w-12 h-12 mx-auto mb-3 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            </div>
            <h3 class="font-semibold text-slate-700 capitalize">${cat}</h3>
          </button>
        `).join('')}
      </div>
    </div>
    <div class="max-w-7xl mx-auto px-4 py-8">
      <div class="flex items-center justify-between mb-6">
        <h2 class="text-2xl font-bold text-slate-800">Featured Products</h2>
        <a href="#products" class="text-emerald-600 font-medium hover:text-emerald-700" data-nav="products">View All →</a>
      </div>
      ${featured.length > 0 ? renderGrid(featured) : empty('No products available')}
    </div>
  </div>`;
}

/* ================= PRODUCTS ================= */
function renderProducts() {
  const filtered = state.products.filter(p => {
    const ms = p.name.toLowerCase().includes(state.search.toLowerCase());
    const mc = state.category === 'all' || p.category === state.category;
    return ms && mc;
  });
  const cats = ['all', ...new Set(state.products.map(p => p.category).filter(Boolean))];
  return `
  <div class="max-w-7xl mx-auto px-4 py-8 animate-fade-in">
    <div class="flex flex-col sm:flex-row gap-4 mb-8">
      <div class="flex-1 relative">
        <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <input type="text" id="searchInput" value="${state.search}" placeholder="Search products..." class="input pl-10">
      </div>
      <div class="flex gap-2 overflow-x-auto pb-2">
        ${cats.map(cat => `
          <button class="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${state.category === cat ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}" data-cat="${cat}">${cat === 'all' ? 'All' : cat.charAt(0).toUpperCase() + cat.slice(1)}</button>
        `).join('')}
      </div>
    </div>
    ${filtered.length > 0 ? renderGrid(filtered) : empty('No products found')}
  </div>`;
}

function renderGrid(products) {
  return `
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    ${products.map(p => `
      <div class="card group cursor-pointer" data-slug="${p.slug}">
        <div class="relative h-48 overflow-hidden bg-slate-50">
          <img src="${p.image || 'https://via.placeholder.com/400x300'}" alt="${p.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy">
          <div class="absolute top-3 right-3">
            <span class="badge bg-white/90 text-slate-700 shadow-sm">${p.category || 'General'}</span>
          </div>
        </div>
        <div class="p-4">
          <h3 class="font-semibold text-slate-800 mb-1 line-clamp-1">${p.name}</h3>
          <p class="text-sm text-slate-500 mb-3 line-clamp-2">${p.description || ''}</p>
          <div class="flex items-center justify-between">
            <span class="text-lg font-bold text-emerald-700">${formatPrice(p.price)}</span>
            <span class="text-xs text-slate-400">${p.stock > 0 ? p.stock + ' in stock' : 'Out of stock'}</span>
          </div>
        </div>
      </div>
    `).join('')}
  </div>`;
}

/* ================= PRODUCT DETAIL ================= */
function renderProductDetail() {
  const p = state.products.find(x => x.slug === state.slug);
  if (!p) return empty('Product not found');
  return `
  <div class="max-w-7xl mx-auto px-4 py-8 animate-fade-in">
    <button class="btn-ghost mb-4 flex items-center gap-2" id="backBtn">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
      Back
    </button>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div class="rounded-2xl overflow-hidden bg-slate-50 border border-slate-100">
        <img src="${p.image || 'https://via.placeholder.com/600x400'}" alt="${p.name}" class="w-full h-full object-cover min-h-[300px]">
      </div>
      <div class="flex flex-col">
        <span class="badge bg-emerald-100 text-emerald-700 mb-3 w-fit">${p.category || 'General'}</span>
        <h1 class="text-3xl font-bold text-slate-800 mb-2">${p.name}</h1>
        <p class="text-3xl font-bold text-emerald-700 mb-4">${formatPrice(p.price)}</p>
        <p class="text-slate-600 mb-6 leading-relaxed">${p.description || 'No description available.'}</p>
        <div class="flex items-center gap-2 mb-6 text-sm text-slate-500">
          <svg class="w-5 h-5 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          ${p.stock > 0 ? `<span class="text-emerald-700 font-medium">${p.stock} in stock</span>` : '<span class="text-red-500 font-medium">Out of stock</span>'}
        </div>
      </div>
    </div>
  </div>`;
}

/* ================= LOGIN ================= */
function renderLogin() {
  return `
  <div class="min-h-[70vh] flex items-center justify-center px-4 py-12">
    <div class="w-full max-w-md">
      <div class="bg-white rounded-2xl shadow-xl border border-slate-100 p-8 animate-fade-in">
        <div class="text-center mb-8">
          <div class="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-4 text-emerald-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
          </div>
          <h1 class="text-2xl font-bold text-slate-800">Welcome Back</h1>
          <p class="text-slate-500 mt-1">Sign in to your account</p>
        </div>
        <form id="loginForm" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <input type="email" name="email" required class="input" placeholder="you@example.com">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input type="password" name="password" required class="input" placeholder="••••••••">
          </div>
          <button type="submit" class="btn-primary w-full py-3">Sign In</button>
        </form>
        <p class="text-center text-sm text-slate-500 mt-6">Don't have an account? <a href="#register" class="text-emerald-600 font-medium hover:text-emerald-700" data-nav="register">Sign up</a></p>
      </div>
    </div>
  </div>`;
}

/* ================= REGISTER ================= */
function renderRegister() {
  return `
  <div class="min-h-[70vh] flex items-center justify-center px-4 py-12">
    <div class="w-full max-w-md">
      <div class="bg-white rounded-2xl shadow-xl border border-slate-100 p-8 animate-fade-in">
        <div class="text-center mb-8">
          <div class="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-4 text-emerald-600">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
          </div>
          <h1 class="text-2xl font-bold text-slate-800">Create Account</h1>
          <p class="text-slate-500 mt-1">Start shopping today</p>
        </div>
        <form id="registerForm" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
            <input type="text" name="name" required class="input" placeholder="John Doe">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <input type="email" name="email" required class="input" placeholder="you@example.com">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input type="password" name="password" required class="input" placeholder="••••••••">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Confirm Password</label>
            <input type="password" name="passwordConfirm" required class="input" placeholder="••••••••">
          </div>
          <button type="submit" class="btn-primary w-full py-3">Create Account</button>
        </form>
        <p class="text-center text-sm text-slate-500 mt-6">Already have an account? <a href="#login" class="text-emerald-600 font-medium hover:text-emerald-700" data-nav="login">Sign in</a></p>
      </div>
    </div>
  </div>`;
}

/* ================= ADMIN ================= */
function renderAdmin() {
  if (!state.user || state.user.role !== 'admin') {
    return `
    <div class="max-w-7xl mx-auto px-4 py-20 text-center animate-fade-in">
      <svg class="w-16 h-16 mx-auto mb-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
      <h2 class="text-2xl font-bold text-slate-800 mb-2">Access Denied</h2>
      <p class="text-slate-500">You need admin privileges to access this page.</p>
    </div>`;
  }
  return `
  <div class="max-w-7xl mx-auto px-4 py-8 animate-fade-in">
    <h1 class="text-2xl font-bold text-slate-800 mb-6">Admin Dashboard</h1>
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div class="lg:col-span-1">
        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
          <h2 class="text-lg font-bold text-slate-800 mb-4">Add Product</h2>
          <form id="addProductForm" class="space-y-3">
            <input type="text" name="name" required class="input" placeholder="Product name">
            <input type="number" name="price" required class="input" placeholder="Price" step="0.01">
            <input type="text" name="category" required class="input" placeholder="Category">
            <input type="number" name="stock" class="input" placeholder="Stock" value="0">
            <textarea name="description" required class="input min-h-[80px]" placeholder="Description"></textarea>
            <input type="text" name="image" class="input" placeholder="Image URL (optional)">
            <button type="submit" class="btn-primary w-full py-3">Add Product</button>
          </form>
        </div>
      </div>
      <div class="lg:col-span-2">
        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div class="px-6 py-4 border-b border-slate-100"><h2 class="text-lg font-bold text-slate-800">Products</h2></div>
          <div class="overflow-x-auto">
            <table class="w-full text-sm">
              <thead class="bg-slate-50 text-slate-600 font-medium">
                <tr><td class="px-6 py-3">Name</td><td class="px-6 py-3">Price</td><td class="px-6 py-3">Category</td><td class="px-6 py-3">Stock</td><td class="px-6 py-3 text-right">Actions</td></tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                ${state.products.map(p => `
                  <tr class="hover:bg-slate-50">
                    <td class="px-6 py-3 font-medium text-slate-800">${p.name}</td>
                    <td class="px-6 py-3 text-emerald-700 font-medium">${formatPrice(p.price)}</td>
                    <td class="px-6 py-3"><span class="badge bg-slate-100 text-slate-600">${p.category}</span></td>
                    <td class="px-6 py-3">${p.stock}</td>
                    <td class="px-6 py-3 text-right">
                      <button class="editBtn text-slate-400 hover:text-emerald-600 p-1 transition-colors" data-slug="${p.slug}">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                      </button>
                      <button class="deleteBtn text-slate-400 hover:text-red-600 p-1 ml-1 transition-colors" data-slug="${p.slug}">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

/* ================= EMPTY ================= */
function empty(msg) {
  return `
  <div class="text-center py-16 text-slate-400">
    <svg class="w-16 h-16 mx-auto mb-4 opacity-40" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/></svg>
    <p class="text-lg text-slate-500">${msg}</p>
  </div>`;
}

/* ================= EVENTS ================= */
function attachEvents() {
  // Navigation
  $$('[data-nav]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const view = el.dataset.nav;
      if (view === 'admin' && state.user?.role !== 'admin') {
        showToast('Admin access required', 'error');
        navigate('login');
        return;
      }
      navigate(view);
    });
  });

  // Product click
  $$('[data-slug]').forEach(el => {
    if (el.classList.contains('editBtn') || el.classList.contains('deleteBtn')) return;
    el.addEventListener('click', (e) => {
      if (e.target.closest('.editBtn') || e.target.closest('.deleteBtn')) return;
      navigate('product', { slug: el.dataset.slug });
    });
  });

  // Back
  const bb = $('#backBtn');
  if (bb) bb.addEventListener('click', () => { window.history.back(); const p = getHashParams(); navigate(p.view, p); });

  // Search
  const si = $('#searchInput');
  if (si) {
    si.addEventListener('input', (e) => {
      state.search = e.target.value;
      render();
      setTimeout(() => { const el = $('#searchInput'); if (el) { el.value = state.search; el.focus(); } }, 0);
    });
  }

  // Category
  $$('[data-cat]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.category = btn.dataset.cat;
      if (state.view !== 'products') navigate('products');
      else render();
    });
  });

  // Logout
  const lb = $('#logoutBtn');
  if (lb) lb.addEventListener('click', () => { logout(); showToast('Logged out'); });

  // Login
  const lf = $('#loginForm');
  if (lf) {
    lf.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(lf);
      try {
        const res = await api.login(fd.get('email'), fd.get('password'));
        loginUser(res.token, res.data?.user);
        if (state.user) {
          const me = await api.me();
          if (me) state.user = me.data.user;
        }
        showToast('Welcome back!');
        navigate('home');
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // Register
  const rf = $('#registerForm');
  if (rf) {
    rf.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(rf);
      try {
        const res = await api.signup(fd.get('name'), fd.get('email'), fd.get('password'), fd.get('passwordConfirm'));
        loginUser(res.token, res.data?.user);
        showToast('Account created!');
        navigate('home');
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // Admin - add product
  const apf = $('#addProductForm');
  if (apf) {
    apf.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(apf);
      const data = {
        name: fd.get('name'),
        price: parseFloat(fd.get('price')),
        category: fd.get('category'),
        stock: parseInt(fd.get('stock') || 0),
        description: fd.get('description'),
        image: fd.get('image') || undefined,
      };
      try {
        await api.createProduct(data);
        showToast('Product added!');
        apf.reset();
        await loadProducts();
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // Admin - delete
  $$('.deleteBtn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const slug = btn.dataset.slug;
      if (!confirm('Delete this product?')) return;
      try {
        await api.deleteProduct(slug);
        showToast('Product deleted');
        await loadProducts();
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  });

  // Admin - edit
  $$('.editBtn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const slug = btn.dataset.slug;
      const p = state.products.find(x => x.slug === slug);
      if (!p) return;
      const name = prompt('New name:', p.name);
      if (name === null) return;
      const price = prompt('New price:', p.price);
      if (price === null) return;
      const stock = prompt('New stock:', p.stock);
      if (stock === null) return;
      const desc = prompt('New description:', p.description);
      if (desc === null) return;
      const cat = prompt('New category:', p.category);
      if (cat === null) return;
      api.updateProduct(slug, {
        name: name || p.name,
        price: parseFloat(price) || p.price,
        stock: parseInt(stock) || p.stock,
        description: desc || p.description,
        category: cat || p.category,
      }).then(() => {
        showToast('Product updated');
        loadProducts();
      }).catch(err => showToast(err.message, 'error'));
    });
  });
}

/* ================= DATA ================= */
async function loadProducts() {
  state.loading = true;
  render();
  try {
    const params = state.search ? `?name=${encodeURIComponent(state.search)}` : '';
    const res = await api.products(params);
    state.products = res.data || [];
  } catch (err) {
    showToast('Failed to load products', 'error');
  } finally {
    state.loading = false;
    render();
  }
}

async function init() {
  if (state.token) {
    try {
      const res = await api.me();
      if (res) state.user = res.data.user;
    } catch {
      logout();
    }
  }
  const p = getHashParams();
  navigate(p.view, p);
  await loadProducts();
}

window.addEventListener('hashchange', () => {
  const p = getHashParams();
  navigate(p.view, p);
});

init();
